//
//  ViewController.swift
//  ProyectoPrimerParcial
//
//  Created by Alumno on 9/10/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var playerFondo = AVAudioPlayer ()
    var playerAnimal = AVAudioPlayer()
    
    let urlVaca = Bundle.main.url(forResource: "Audiovaca", withExtension: "mp3")
    
    let urlGato = Bundle.main.url(forResource: "AudioGato", withExtension: "mp3")
    
    let urlConejo = Bundle.main.url(forResource: "rabbitsounds", withExtension: "mp3")
    
    let urlFondo = Bundle.main.url(forResource: "fondo", withExtension: "wav")
    
    
    let ConejoCorriendo  = [
                 UIImage(named: "conejito1")!,
                 UIImage(named: "conejito2")!,
                 UIImage(named: "conejito3")!,
                 UIImage(named: "conejito4")!,
                 UIImage(named: "conejito5")!
             ]
      
    let Conejo2  = [
                    UIImage(named: "conejo1")!,
                    UIImage(named: "conejo2")!,
                    UIImage(named: "conejo3")!,
                    UIImage(named: "conejo4")!,
                    UIImage(named: "conejo5")!
                ]
         
      
    let VaquitaAnimada = [
          
                  UIImage(named: "vaquita1")!,
                  UIImage(named: "vaquita2")!,
                  UIImage(named: "vaquita3")!,
                  UIImage(named: "vaquita4")!,
                  UIImage(named: "vaquita5")!
                 
          ]
      
      let Vaquita2 = [
              
                  UIImage(named: "moo1")!,
                  UIImage(named: "moo2")!,
                  UIImage(named: "moo3")!,
                  UIImage(named: "moo4")!,
                  UIImage(named: "moo5")!
      
      
      ]
      
      let GatoAnimado = [
          
                  UIImage(named: "miau1")!,
                  UIImage(named: "miau2")!,
                  UIImage(named: "miau3")!,
                  UIImage(named: "miau4")!,
                  UIImage(named: "miau5")!
      ]
      
      let Gato2 = [
               
                   UIImage(named: "gatito1")!,
                   UIImage(named: "gatito2")!,
                   UIImage(named: "gatito3")!,
                   UIImage(named: "gatito4")!,
                   UIImage(named: "gatito5")!
       
       
       ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
            do{
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                
                playerFondo = try AVAudioPlayer(contentsOf: urlFondo!, fileTypeHint: AVFileType.wav.rawValue)
                playerFondo.numberOfLoops = -1
                playerFondo.volume = 0.2
                
                imgConejo.animationImages = ConejoCorriendo
                imgConejo.animationDuration = 2.0
                imgConejo.startAnimating()
                
                imgGato.animationImages = GatoAnimado
                imgGato.animationDuration = 2.0
                imgGato.startAnimating()
                
                imgVaca.animationImages = VaquitaAnimada
                imgVaca.animationDuration = 2.0
                imgVaca.startAnimating()
                
                
                
                playerFondo.play()
                
            } catch let error{
                print(error.localizedDescription)
        }
    }
    
  
    
    
   
    
       
  @IBOutlet weak var lblAnimal: UILabel!
  @IBOutlet weak var imgMain: UIImageView!
    
  @IBOutlet weak var imgVaca: UIImageView!
    @IBAction func TapAnimal1(_ sender: Any) {
        do{
            playerAnimal = try AVAudioPlayer(contentsOf: urlVaca!, fileTypeHint: AVFileType.mp3.rawValue)
            playerAnimal.play()
            
            
            imgMain.animationImages = Vaquita2
            imgMain.animationDuration = 2.0
            imgMain.startAnimating()
            
            lblAnimal.text = "Cow"
            
            
        }catch let error{
            print(error.localizedDescription)
        }
        
        
    }
    
    
    
    @IBOutlet weak var imgGato: UIImageView!
    @IBAction func TapAnimal2(_ sender: Any) {
        do{
                playerAnimal = try AVAudioPlayer(contentsOf: urlGato!, fileTypeHint: AVFileType.mp3.rawValue)
                playerAnimal.play()
                
                
                imgMain.animationImages = Gato2
                imgMain.animationDuration = 2.0
                imgMain.startAnimating()
            
                lblAnimal.text = "Kitten"
               
            
                  
              }catch let error{
                  print(error.localizedDescription)
              }
        
        
        
    }
    
    
    
    @IBOutlet weak var imgConejo: UIImageView!
    @IBAction func TapAnimal3(_ sender: Any) {
        do{
                playerAnimal = try AVAudioPlayer(contentsOf: urlConejo!, fileTypeHint: AVFileType.mp3.rawValue)
                playerAnimal.play()
            
                
            
                imgMain.animationImages = Conejo2
                imgMain.animationDuration = 2.0
                imgMain.startAnimating()
            
                lblAnimal.text = "Rabbit"
            
                        
                    }catch let error{
                        print(error.localizedDescription)
                    }
        
               
        
    }
    
}


